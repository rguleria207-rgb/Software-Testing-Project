const { test, expect } = require('@playwright/test');

const API = 'https://fakestoreapi.com';

// TEST 1: Get All Products
test('Test 1: Products API', async ({ request }) => {
    const response = await request.get(`${API}/products`);

    expect(response.status()).toBe(200);

    const products = await response.json();

    expect(products.length).toBeGreaterThan(0);
});

// TEST 2: Get Shopping Carts
test('Test 2: Shopping Cart API', async ({ request }) => {
    const response = await request.get(`${API}/carts`);

    expect(response.status()).toBe(200);

    const carts = await response.json();

    expect(Array.isArray(carts)).toBeTruthy();
});

// TEST 3: Get Single Product
test('Test 3: Single Product Details', async ({ request }) => {
    const response = await request.get(`${API}/products/1`);

    expect(response.status()).toBe(200);

    const product = await response.json();

    expect(product.id).toBe(1);
    expect(product.title).toBeTruthy();
});

// TEST 4: Create Shopping Cart
test('Test 4: Create Shopping Cart', async ({ request }) => {
    const response = await request.post(`${API}/carts`, {
        data: {
            userId: 1,
            products: [
                { productId: 1, quantity: 2 }
            ]
        }
    });

    expect(response.ok()).toBeTruthy();

    const cart = await response.json();

    expect(cart.userId).toBe(1);
    expect(cart.products[0].quantity).toBe(2);
});

// TEST 5: Validate Product Price
test('Test 5: Validate Product Price', async ({ request }) => {
    const response = await request.get(`${API}/products/1`);

    expect(response.status()).toBe(200);

    const product = await response.json();

    expect(product).toHaveProperty('price');
    expect(typeof product.price).toBe('number');
    expect(product.price).toBeGreaterThan(0);
});